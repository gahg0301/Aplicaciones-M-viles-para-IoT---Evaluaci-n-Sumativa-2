package com.example.trabajo.model;

public class TipoSensor {
    private String nombre;

    public TipoSensor(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
